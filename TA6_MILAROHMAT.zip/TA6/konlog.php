<?php
$koneksi = new mysqli("localhost", "root", "", "ta");

  			if (isset($_POST['submit'])) {
				$koneksi = new mysqli("localhost", "root", "", "ta");

				if ($koneksi) {
					$id_user = $_POST['id_user'];
					$password = $_POST['password'];
					
					
					$sql = $koneksi->query("
						INSERT INTO `login` (`id_user`, `password`)
						VALUES ('id_user', '$password')
										   ");
					echo "LOGIN SUKSES<br>";
				
			
					echo "LOGIN GAGAL";
				
				}else{
				}
  			}
 ?>