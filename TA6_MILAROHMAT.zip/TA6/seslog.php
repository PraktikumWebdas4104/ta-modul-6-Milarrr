<?php
session_start();
include 'konlog.php';

$id_user    = $_POST['id_user'];
$password    = $_POST['password'];

echo " data berhasil disimpan"
	
?>
 <a href="daftar.html"> Lanjut registrasi </a>

