<?php
session_start();
include "kondaf.php";

?>
 <a href="halamanawal.html"> Lanjut halaman awal </a>