<html>
<title> posting </title>
		<form method="post" action="posting2.php">
		<body> 
			<table border="2" width="700">
	<tr>
		<th width="250"><a href = "halamanawal.html">Home</a></th>
		<th width="250"><a href="editprofile.php">Edit Profile</a></th>
		<th width="100"><a href="posting.html">Posting</a></th>
		<th width="300"><a href="posting1.php">Lihat Postingan</a></th>
		<th width="360"><a href="posting2.php">Lihat Postingan semua</a></th>
	</tr>
</table></center><br><br> 
</body>
</form>
</html>
<?php 
mysql_connect("localhost", "root", "ta");  
 mysql_select_db("ta");  
 $judul=$_POST['judul'];  
 $deskripsi=$_POST['deskripsi'];   
 $waktu = date('Y-m-d H:i:s');  
  
 if (isset($_POST['simpan'])){  
  $fileName = $_FILES['path']['name'];  
  
  $sql = "insert into upload Values (NULL, '$judul', '$deskripsi', '$fileName', '$waktu')";  
  mysql_query($sql);  

  move_uploaded_file($_FILES['path']['tmp_name'], "image/".$_FILES['path']['name']);  
  echo"<script>alert('Gambar Berhasil diupload !');history.go(-1);</script>";  
 }  
 ?>  