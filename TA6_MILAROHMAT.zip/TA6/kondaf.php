<?php
$koneksi = new mysqli("localhost", "root", "", "ta");

  			if (isset($_POST['submit'])) {
				$koneksi = new mysqli("localhost", "root", "", "ta");

				if ($koneksi) {
					$nama		   = $_POST['nama'];
					$nim		  =$_POST['nim'];
					$kelas			=$_POST['kelas'];
					$jeniskelamin = $_POST['jeniskelamin'];
					$program         = $_POST['program'];
					$hobi			 = $_POST['hobi'];
					$fakultas       = $_POST['fakultas'];
					$alamat			=$_POST['alamat'];
					$password		=$_POST['password'];
					
					$sql = $koneksi->query("
						INSERT INTO `regis` (`nama`,`nim`,`kelas`,`jeniskelamin`,`program`,`hobi`,`fakultas`,`alamat`,`password`)
						VALUES ('$nama','$nim','$kelas','$jeniskelamin', '$program','$hobi','$fakultas','$alamat','$password')
										   ");
					echo "DATA SUKSES TERSIMPAN <br>";

				}else{
			
					echo "DATA GAGAL DISIMPAN";
				
				
				}
  			}
 ?>