<?php 
mysql_connect("localhost", "root", "");  
    mysql_select_db("ta");  
       $sql = mysql_query(" SELECT * FROM upload");  
       while ($baris=mysql_fetch_array($sql))  
       {   
        $formatted = date('d-M-Y H:i:s', strtotime($baris['waktu']));  
        echo $formatted;  
        echo "<br>";  
        echo "Judul :".$baris[1]."<br><br>";  
        echo "<img src=image/".$baris['path'].">"; echo "Berita :".$baris[2]."<br>";  
        echo"<br><br><hr>";  
       }  
   ?>  