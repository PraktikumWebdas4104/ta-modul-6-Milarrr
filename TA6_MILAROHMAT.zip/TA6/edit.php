<html>
	<head></head>
		<title> HOME </title>
		<table>
			<h1> Masukkan biodata </h1>
			<th width="250"><a href = "halamanawal.html">Home</a></th>
			<th width="250"><a href="editprofile.php">Edit Profile</a></th>
			<th width="100"><a href="posting.html">Posting</a></th>
			<th width="300"><a href="posting1.php">Lihat Postingan</a></th>
			<th width="360"><a href="posting2.php">Lihat Postingan semua</a></th>
		</tr>
</table></center><br>
	<form method="post" action="indaf.php">
		<table>
 Nama 		   : <input type="text" name="nama" maxlength="35"> <br><br>
 Nim		   : <input type="number" name="nim" maxlength="10"><br><br>
 Kelas 		   : <input type="radio" name="kelas" value="D3MI4101"> D3MI4101<br>
 				 <input type="radio" name="kelas" value="D3MI4102"> D3MI4102<br>
				<input type="radio" name="kelas" value="D3MI4103"> D3MI4103<br>
				<input type="radio" name="kelas" value="D3MI4104"> D3MI4104<br><br>
 Jenis Kelamin : <br>&nbsp&nbsp&nbsp&nbsp<input type="radio" name="jeniskelamin" value="Laki-laki"> Laki-laki<br>
					&nbsp&nbsp&nbsp&nbsp<input type="radio" name="jeniskelamin" value="Perempuan"> Perempuan<br><br>
 Program Studi : <select name="program"> <br><br>
  						<option value="Manajemen Informatika">Manajemen Informatika</option><br>
 						<option value="Teknik Informatika">Teknik Informatika</option><br>
  						<option value="Akuntansi">Akuntansi</option><br>
  						<option value="MBTI">MBTI</option><br>
				</select> <br><br>
Hobi 		  :  <br> &nbsp&nbsp&nbsp&nbsp<input type="checkbox" name="hobi" value="baca"> Membaca Buku<br>
  				 &nbsp &nbsp&nbsp<input type="checkbox" name="hobi" value="nulis"> Menulis <br>
  				 &nbsp&nbsp&nbsp<input type="checkbox" name="hobi" value="main" > Bermain<br><br>
Fakultas 	  : <select name="fakultas"><br><br>
  						<option value="Ilmu Terapan">Ilmu Terapan</option><br>
 						<option value="Komunikasi">Komunikasi Bisnis</option><br>
  						<option value="Iindustri Kreatif">Industri Kreatif</option><br>
  						<option value="Elektro">Elektro</option><br><br>
				</select><br><br>
 Alamat	      : <input type ="textarea" name="alamat"> <br><br>
 Password 	  : <input type="Password" name="password">
 		
 	</table>
 		<input type="submit" name="update" value="update"> &nbsp&nbsp <a href="daftar.html"><input type="button" name="back" value="Kembali"></a>

	</form>
</html>
<?php 
	error_reporting(0);

	if(isset($_POST['update'])){
		$nama=$_POST['nama'];
		$nim=$_POST['nim'];
		$kelas=$_POST['kelas'];
		$jeniskelamin=$_POST['jeniskelamin'];
		$hobby=$_POST['hobi'];
		$fakultas=$_POST['fakultas'];
		$alamat=$_POST['alamat'];
		$password=$_POST['password'];
		$host="localhost";
		$user="root";
		$pass="";
		$db="ta";
		$conn=mysqli_connect($host,$user,$pass,$db);

		$sql=$conn->query("UPDATE `regis` SET `nama`='$nama',`nim`='$nim',`kelas`='$kelas',`jenis_kelamin`='$jeniskel',`hobi`='$hobi',`fakultas`='$fakultas',`alamat`='$alamat',`password`='$password'");
		echo "data berhasil diupdate";

	}


 ?>